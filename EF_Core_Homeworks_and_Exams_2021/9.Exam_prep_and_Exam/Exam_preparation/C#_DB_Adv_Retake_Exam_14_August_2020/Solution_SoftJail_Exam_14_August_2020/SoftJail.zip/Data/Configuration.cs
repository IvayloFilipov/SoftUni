﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=SoftJailSecond;Trusted_Connection=True";
    }
}
